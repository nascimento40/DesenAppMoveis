package com.example.exercicios2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.exercicios2.databinding.ActivityViewNoteBinding

class ViewNoteActivity : AppCompatActivity() {

    private lateinit var binding: ActivityViewNoteBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityViewNoteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val noteContent = intent.getStringExtra("note_content")
        binding.txtNote.text = noteContent
    }
}

