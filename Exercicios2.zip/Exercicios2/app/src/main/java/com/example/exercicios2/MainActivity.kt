package com.example.exercicios2

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import com.example.exercicios2.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var notesList: MutableList<String>
    private lateinit var listView: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPreferences = getSharedPreferences("notes", MODE_PRIVATE)
        listView = binding.listNotes

        binding.btnAddNote.setOnClickListener {
            val intent = Intent(this, AddNoteActivity::class.java)
            startActivityForResult(intent, ADD_NOTE_REQUEST)
        }

        notesList = mutableListOf()
        val notesSet = sharedPreferences.getStringSet("notes_set", mutableSetOf())
        notesList.addAll(notesSet ?: emptySet())
        updateNotesList()
    }

    private fun updateNotesList() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, notesList)
        listView.adapter = adapter

        listView.setOnItemClickListener { _, _, position, _ ->
            val note = notesList[position]
            val intent = Intent(this, ViewNoteActivity::class.java)
            intent.putExtra("note_content", note)
            startActivity(intent)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == ADD_NOTE_REQUEST && resultCode == RESULT_OK) {
            val note = data?.getStringExtra("note")
            note?.let {
                notesList.add(it)
                val editor = sharedPreferences.edit()
                editor.putStringSet("notes_set", notesList.toSet())
                editor.apply()
                updateNotesList()
            }
        }
    }

    companion object {
        private const val ADD_NOTE_REQUEST = 1
    }
}


