package com.example.exercicios22

import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.exercicios22.databinding.ActivityIncrementBinding

class IncrementActivity : AppCompatActivity() {

    private lateinit var binding: ActivityIncrementBinding
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityIncrementBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPreferences = getSharedPreferences("counter", MODE_PRIVATE)

        binding.btnIncrementCount.setOnClickListener {
            val count = sharedPreferences.getInt("count", 0)
            val editor = sharedPreferences.edit()
            editor.putInt("count", count + 1)
            editor.apply()
        }
    }
}
