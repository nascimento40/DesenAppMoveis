package com.example.exercicios22

import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.exercicios22.databinding.ActivityViewCountBinding

class ViewCountActivity : AppCompatActivity() {

    private lateinit var binding: ActivityViewCountBinding
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityViewCountBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPreferences = getSharedPreferences("counter", MODE_PRIVATE)

        val count = sharedPreferences.getInt("count", 0)
        binding.tvCount.text = "Contagem: $count"
    }
}
