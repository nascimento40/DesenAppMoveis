package com.example.prova

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.prova.databinding.ActivityCadastroBinding

class CadastroActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCadastroBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityCadastroBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val edtTitulo = binding.edtTitulo2
        val edtData = binding.edtData2
        val edtHoraInicio = binding.edtHoroInicio2
        val edtHoraFim = binding.edtHoroFim2
        val edtDescricao = binding.edtDescricao2
        // Adicione os outros EditTexts aqui

        val btnCadastrar = binding.btnCadastrar


        btnCadastrar.setOnClickListener {

            val titulo = edtTitulo.text.toString()
            val data = edtData.text.toString()
            val horaInicio = edtHoraInicio.text.toString()
            val horaFim = edtHoraFim.text.toString()
            val descricao = edtDescricao.text.toString()
            // Obtenha os valores dos outros EditTexts

            if (titulo.isNotEmpty()) {
                val compromisso = Compromisso(
                    titulo = titulo,
                    data = data,
                    horaInicio = horaInicio,
                    horaFim = horaFim,
                    Descricao = descricao
                )
                ListaCompromisso.addCompromisso(compromisso)
                Toast.makeText(this, "Compromisso cadastrado", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
