package com.example.prova

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class CompromissoAdapter (var context: Context): RecyclerView.Adapter<CompromissoViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CompromissoViewHolder {
        val layoutCarro = LayoutInflater.from(parent.context)
            .inflate(R.layout.layout_compromisso, parent, false)
        return CompromissoViewHolder(layoutCarro)
    }

    override fun getItemCount(): Int {
        return ListaCompromisso.getListSize()
    }

    override fun onBindViewHolder(holder: CompromissoViewHolder, position: Int) {
        val compromisso = ListaCompromisso.getCompromisso(position)
        holder.txtTituloData.text = "${compromisso.titulo} (${compromisso.data})"

        holder.txtTituloData.setOnLongClickListener {
            var intent = Intent(context, DetalhesActivity::class.java)
            intent.putExtra("position", position)
            holder.itemView.context.startActivity(intent)
            true
        }
    }
}