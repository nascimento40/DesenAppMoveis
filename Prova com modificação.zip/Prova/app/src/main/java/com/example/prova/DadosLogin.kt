package com.example.prova

import android.content.Context
import android.content.SharedPreferences

class DadosLogin(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE)

    fun setEmail(email: String) {
        prefs.edit().putString(Util.CHAVE_EMAIL, email).apply()
    }

    fun setSenha(senha: String) {
        prefs.edit().putString(Util.CHAVE_SENHA, senha).apply()
    }

    fun getEmail(): String? {
        return prefs.getString(Util.CHAVE_EMAIL, Util.EMAIL_PADRAO)
    }

    fun getSenha(): String? {
        return prefs.getString(Util.CHAVE_SENHA, Util.SENHA_PADRAO)
    }

    fun clearLoginData() {
        prefs.edit().remove(Util.CHAVE_EMAIL).remove(Util.CHAVE_SENHA).apply()
    }

    fun continuarLogado(valor : Boolean) {
        prefs.edit()
            .putBoolean(Util.CHAVE_LOGAO, valor)
            .apply()
    }

    fun getLogado() : Boolean {
        return prefs.getBoolean(Util.CHAVE_LOGAO, false)
    }
}
