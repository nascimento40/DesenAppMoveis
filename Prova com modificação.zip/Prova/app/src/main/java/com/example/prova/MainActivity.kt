package com.example.prova

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.prova.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var compromissoAdapter: CompromissoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        compromissoAdapter = CompromissoAdapter(this)
        binding.rcvCompromisso.layoutManager = LinearLayoutManager(this)
        binding.rcvCompromisso.adapter = compromissoAdapter

        binding.btnAdd.setOnClickListener {
            startActivity(Intent(this, CadastroActivity::class.java))
        }

        val btnExcluirTodos = findViewById<Button>(R.id.btnExcluirTodos)

        binding.btnExcluirTodos.setOnClickListener {
            ListaCompromisso.clearCompromissos() // Chame um método para limpar todos os compromissos na ListaCompromisso
            compromissoAdapter.notifyDataSetChanged() // Notifique o adaptador para atualizar a RecyclerView
        }

    }

    override fun onStart() {
        super.onStart()
        compromissoAdapter.notifyDataSetChanged()
    }
}
