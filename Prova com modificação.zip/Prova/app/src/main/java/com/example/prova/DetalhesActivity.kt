package com.example.prova

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.prova.databinding.ActivityDetalhesBinding

class DetalhesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetalhesBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDetalhesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val position = intent.getIntExtra("position", -1)

        if (position == -1) { finish() }

        val compromisso = ListaCompromisso.getCompromisso(position)

        binding.txtTitulo.text = compromisso.titulo
        binding.txtData.text = compromisso.data
        binding.txtHoraInicio.text = compromisso.horaInicio
        binding.txtHoraFim.text = compromisso.horaFim
        binding.txtDescricao.text = compromisso.Descricao

        binding.btnExcluir.setOnClickListener {
            ListaCompromisso.removeComnpromisso(position)
            finish()
        }

    }
}