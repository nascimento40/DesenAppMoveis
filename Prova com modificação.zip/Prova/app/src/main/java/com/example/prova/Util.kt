package com.example.prova

import android.content.Context
import android.widget.Toast

class Util {
    companion object {
        val CHAVE_EMAIL = "email"
        val CHAVE_SENHA  = "senha"
        val CHAVE_LOGAO = "logado"
        val EMAIL_PADRAO = "emiliano.nascimento@gmail.com"
        val SENHA_PADRAO = "1234"

        // exibe um toast com base no contexto e string recebidos via parametro
        fun exibirToast(context: Context, msg: String) {
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        }

    }
}