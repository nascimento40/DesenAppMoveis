package com.example.prova2

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "carros")
data class Carro(
    @PrimaryKey(autoGenerate = true) @ColumnInfo(name = "id") var id: Int,
    @ColumnInfo(name = "marca") var marca: String,
    @ColumnInfo(name = "modelo") var modelo: String,
    @ColumnInfo(name = "ano") var ano: String
) {
}