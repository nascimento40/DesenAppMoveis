package com.example.prova2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.prova2.databinding.ActivityCadastroBinding

class CadastroActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCadastroBinding
    private val dao = CarrosDB.getInstance(this).getCarrosDAO()
    private var id = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCadastroBinding.inflate(layoutInflater)
        setContentView(binding.root)

        id = intent.getIntExtra("id", 0)

        if (id > 0) {
            var temp = dao.buscarCarro(id)

            binding.edtMarca.setText(temp.marca)
            binding.edtModelo.setText(temp.modelo)
            binding.edtAno.setText(temp.ano)
        }

        binding.btnSalvar.setOnClickListener {
            validarDados()
        }
    }

    fun validarDados() {
        if (binding.edtMarca.text.isEmpty() ||
            binding.edtModelo.text.isEmpty() ||
            binding.edtAno.text.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
            return
        }

        var carro = Carro(
            id,
            binding.edtMarca.text.toString(),
            binding.edtModelo.text.toString(),
            binding.edtAno.text.toString()
        )

        if (id > 0) {
            dao.atualizarCarro(carro)
            finish()
            return

        }
        if (dao.salvarCarro(carro) > 0) {
            Toast.makeText(this, "Carro cadastrado", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}