package com.example.prova2

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Carro::class], version = 1)
abstract class CarrosDB: RoomDatabase() {

    abstract fun getCarrosDAO(): CarroDAO

    companion object {
        private lateinit var INSTANCE : CarrosDB
        fun getInstance(context: Context): CarrosDB {
            if (!::INSTANCE.isInitialized) {
                INSTANCE = Room.databaseBuilder(context, CarrosDB::class.java, "concecionaria")
                    .allowMainThreadQueries()
                    .build()
            }
            return INSTANCE
        }
    }
}