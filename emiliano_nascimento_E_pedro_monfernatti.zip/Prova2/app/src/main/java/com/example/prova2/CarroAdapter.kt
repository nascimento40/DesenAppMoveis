package com.example.prova2

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class CarroAdapter(val context: Context) : RecyclerView.Adapter<CarroViewHolder>() {

    val dao = CarrosDB.getInstance(context).getCarrosDAO()
    var listaCarros = dao.buscarCarros()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CarroViewHolder {
        val carroLayout = LayoutInflater.from(context)
            .inflate(R.layout.carro_layout,parent,false)
        val carroViewHolder = CarroViewHolder(carroLayout)
        return carroViewHolder
    }

    override fun getItemCount(): Int {
        return listaCarros.size
    }

    override fun onBindViewHolder(holder: CarroViewHolder, position: Int) {
        val carro = listaCarros.get(position)
            holder.txtMarca.text = "Marca: ${carro.marca}"
        holder.txtModelo.text = "Modelo: ${carro.modelo}"
        holder.txtAno.text = "Ano: ${carro.ano}"

        holder.txtMarca.setOnClickListener {
            var intent = Intent(context, CadastroActivity::class.java)
            intent.putExtra("id",carro.id)
            context.startActivity(intent)
        }

        holder.txtMarca.setOnLongClickListener {
            dao.deletarCarro(carro)
            Toast.makeText(context, "Carro excluído com sucesso!", Toast.LENGTH_SHORT).show()
            atualizarAdapter()

            true
        }
    }

    fun atualizarAdapter() {
        listaCarros = emptyList()
        listaCarros = dao.buscarCarros()
        notifyDataSetChanged()
    }
}