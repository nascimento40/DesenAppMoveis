package com.example.prova2

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CarroViewHolder(carroLayout: View) : RecyclerView.ViewHolder(carroLayout) {
    val txtMarca = carroLayout.findViewById<TextView>(R.id.txtMarca)
    val txtModelo = carroLayout.findViewById<TextView>(R.id.txtModelo)
    val txtAno = carroLayout.findViewById<TextView>(R.id.txtAno)
}