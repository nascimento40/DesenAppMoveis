package com.example.prova2

import androidx.room.*

@Dao
interface CarroDAO {

    @Insert
    fun salvarCarro(carro: Carro): Long

    @Delete
    fun deletarCarro(carro: Carro)

    @Update
    fun atualizarCarro(carro: Carro)

    @Query("SELECT * FROM carros")
    fun buscarCarros() : List<Carro>

    @Query("SELECT * FROM carros WHERE id = :id")
    fun buscarCarro(id: Int) : Carro

    @Query("SELECT COUNT(*) FROM carros")
    fun totalCarros() : Int
}