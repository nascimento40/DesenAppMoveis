package com.example.aulanaosei

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.create

abstract class RetrofitClient {
    companion object {
        private const val BASE_URL = "https://jsonplaceholder.typicode.com/"
        private lateinit var INSTANCE : Retrofit

        fun getRetrofitInstance(): Retrofit{
            if (!::INSTANCE.isInitialized) {
                val HTTP = OkHttpClient.Builder()
                INSTANCE = Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .client(HTTP.build())
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
            }
            return INSTANCE
        }

        fun createPostService(): PostService {
            return getRetrofitInstance().create(PostService::class.java)
        }
    }
}