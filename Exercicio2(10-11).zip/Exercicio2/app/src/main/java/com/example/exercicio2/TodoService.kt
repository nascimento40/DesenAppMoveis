package com.example.exercicio2

/*import retrofit2.Call
import retrofit2.http.GET

interface TodoService {
    @GET("todos")
    fun getTodos(): Call<List<TodoEntity>>
}*/

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface TodoService {
    @GET("todos")
    fun getTodos(@Query("userId") userId: Int): Call<List<TodoEntity>>
}


