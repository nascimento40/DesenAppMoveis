package com.example.exercicio2

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var todoRecyclerView: RecyclerView
    private lateinit var todoAdapter: TodoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        todoRecyclerView = findViewById(R.id.todoRecyclerView)
        todoAdapter = TodoAdapter()
        todoRecyclerView.layoutManager = LinearLayoutManager(this)
        todoRecyclerView.adapter = todoAdapter

        val service = RetrofitClient.createTodoService()
        //val call: Call<List<TodoEntity>> = service.getTodos()
        val call: Call<List<TodoEntity>> = service.getTodos(userId = 1) // Passe o ID do usuário desejado

        call.enqueue(object : Callback<List<TodoEntity>> {
            override fun onResponse(call: Call<List<TodoEntity>>, response: Response<List<TodoEntity>>) {
                val todos = response.body()
                if (todos != null) {
                    todoAdapter.todoList = todos
                    todoAdapter.notifyDataSetChanged()
                }
            }

            override fun onFailure(call: Call<List<TodoEntity>>, t: Throwable) {
                // Handle failure
            }
        })
    }
}
