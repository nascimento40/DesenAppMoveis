package com.example.exercicio2

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitClient {
    private const val BASE_URL = "https://jsonplaceholder.typicode.com/"
    private lateinit var INSTANCE: Retrofit

    fun getRetrofitInstance(): Retrofit {
        if (!::INSTANCE.isInitialized) {
            val httpClient = OkHttpClient.Builder()
            INSTANCE = Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(httpClient.build())
                .addConverterFactory(GsonConverterFactory.create())
                .build()
        }
        return INSTANCE
    }

    fun createTodoService(): TodoService {
        return getRetrofitInstance().create(TodoService::class.java)
    }
}
