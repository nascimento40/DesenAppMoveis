package com.example.aula6

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.aula6.databinding.ActivityLoginBinding
import java.util.prefs.AbstractPreferences

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    // criar shared preferences
    private lateinit var sharedPreferences: SharedPreferences

    // temporariamente, criaremos valores fixos para dados login
    private val EMAIL = "eliano@gmail.com"
    private val SENHA = "senha"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityLoginBinding.inflate(layoutInflater)
        sharedPreferences = getSharedPreferences("Login", Context.MODE_PRIVATE)

        setContentView(binding.root)

        // acao de clique do botao
        binding.btnEntrar.setOnClickListener {
            validarLogin()
        }
    }

    override fun onStop() {
        super.onStop()
        finish()
    }

    private fun validarLogin() {

        if (binding.edtEmail.text.isEmpty() || binding.edtSenha.text.isEmpty()) {
            // mensagem de erro
            exibirToast("Preencha todos os campos")
            return
        }

        var email = binding.edtEmail.text.toString()
        var senha = binding.edtSenha.text.toString()

        if (binding.ckbPrimeiroAcesso.isChecked) {
            // armazenar dado de email e senha no sharedPreferences
            var editor = sharedPreferences.edit()

            editor.putString("email", email)
            editor.putString("senha", senha)
            editor.apply()

            exibirToast("Dados de login registrados")

        } else {
            var shareEmail = sharedPreferences.getString("email", EMAIL)
            var shareSenha = sharedPreferences.getString("senha", SENHA)

            if (email != shareEmail || senha != shareSenha) {
                exibirToast("E-mail ou senha invalidos!")
                binding.edtEmail.text.clear()
                binding.edtSenha.text.clear()
                return
            }

        }

        binding.ckbPrimeiroAcesso.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                // Redirecionar para a atividade de cadastro
                val intent = Intent(this, CadastroActivity::class.java)
                startActivity(intent)
            }
        }

        //iniciar a main activity
        var intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    private fun exibirToast (mensagem : String) {
        Toast.makeText(this, mensagem, Toast.LENGTH_SHORT).show()
    }
}