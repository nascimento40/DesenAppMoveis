package com.example.aula6

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.aula6.databinding.ActivityCadastroBinding

class CadastroActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCadastroBinding
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityCadastroBinding.inflate(layoutInflater)
        sharedPreferences = getSharedPreferences("Login", Context.MODE_PRIVATE)

        setContentView(binding.root)

        binding.btnCadastrar.setOnClickListener {
            realizarCadastro()
        }
    }

    private fun realizarCadastro() {
        val novoEmail = binding.edtNovoEmail.text.toString()
        val novaSenha = binding.edtNovaSenha.text.toString()

        if (novoEmail.isEmpty() || novaSenha.isEmpty()) {
            exibirToast("Preencha todos os campos")
            return
        }

        // Armazenar o novo email e senha no SharedPreferences
        val editor = sharedPreferences.edit()
        editor.putString("email", novoEmail)
        editor.putString("senha", novaSenha)
        editor.apply()

        exibirToast("Cadastro realizado com sucesso")

        // Finalizar a atividade de cadastro e retornar à LoginActivity
        finish()
    }

    private fun exibirToast(mensagem: String) {
        Toast.makeText(this, mensagem, Toast.LENGTH_SHORT).show()
    }
}