package model

data class User(
    val weight: Double,
    val height: Double
)
