package viewModel

import androidx.lifecycle.ViewModel

class IMCCalculatorViewModel : ViewModel() {
    fun calculateIMC(weight: Double, height: Double): Double {
        return weight / (height * height)
    }
}