package viewModel

import androidx.lifecycle.ViewModel

class TemperatureConverterViewModel : ViewModel() {
    fun celsiusToFahrenheit(celsius: Double): Double {
        return celsius * 9 / 5 + 32
    }
}

