package viewModel

import androidx.lifecycle.ViewModel

class AverageCalculatorViewModel : ViewModel() {
    fun calculateWeightedAverage(scores: List<Double>, weights: List<Int>): Double {
        if (scores.size != weights.size) {
            throw IllegalArgumentException("O número de notas e pesos deve ser o mesmo.")
        }

        var totalScore = 0.0
        var totalWeight = 0

        for (i in scores.indices) {
            val score = scores[i]
            val weight = weights[i]

            if (score < 0.0 || score > 10.0 || weight <= 0) {
                throw IllegalArgumentException("Notas devem estar entre 0 e 10, e pesos devem ser positivos.")
            }

            totalScore += score * weight
            totalWeight += weight
        }

        return totalScore / totalWeight
    }
}
