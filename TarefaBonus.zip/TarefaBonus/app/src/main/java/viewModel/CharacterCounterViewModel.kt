package viewModel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class CharacterCounterViewModel : ViewModel() {
    private val _characterCount = MutableLiveData<Int>()
    val characterCount: LiveData<Int>
        get() = _characterCount

    fun countCharacters(text: String) {
        _characterCount.value = text.length
    }
}
