package viewModel

import androidx.lifecycle.ViewModel

class CurrencyConverterViewModel : ViewModel() {
    val exchangeRateUSDToEUR = 0.85 // Taxa de câmbio fixa USD para EUR

    fun convertUSDToEUR(usdAmount: Double): Double {
        return usdAmount * exchangeRateUSDToEUR
    }
}
