package view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.tarefabonus.databinding.ActivityCharacterCounterBinding
import viewModel.CharacterCounterViewModel

class CharacterCounterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCharacterCounterBinding
    private lateinit var viewModel: CharacterCounterViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCharacterCounterBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        viewModel = ViewModelProvider(this).get(CharacterCounterViewModel::class.java)

        viewModel.characterCount.observe(this, Observer {
            binding.tvResult.text = "Número de Caracteres: $it"
        })

        binding.btnCount.setOnClickListener {
            val inputText = binding.etInputText.text.toString()
            viewModel.countCharacters(inputText)
        }
    }
}
