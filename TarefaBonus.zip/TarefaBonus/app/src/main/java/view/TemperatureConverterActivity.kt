package view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.tarefabonus.databinding.ActivityTemperatureConverterBinding
import viewModel.TemperatureConverterViewModel

class TemperatureConverterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityTemperatureConverterBinding
    private lateinit var viewModel: TemperatureConverterViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTemperatureConverterBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        viewModel = ViewModelProvider(this).get(TemperatureConverterViewModel::class.java)

        binding.btnConvert.setOnClickListener {
            val celsiusStr = binding.etCelsius.text.toString()

            if (celsiusStr.isNotEmpty()) {
                val celsius = celsiusStr.toDouble()
                val result = viewModel.celsiusToFahrenheit(celsius)
                binding.tvResult.text = "Resultado: $result °F"
            } else {
                Toast.makeText(this, "Digite a temperatura em Celsius", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
