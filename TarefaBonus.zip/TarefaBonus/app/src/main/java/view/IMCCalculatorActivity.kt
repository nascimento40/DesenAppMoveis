package view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.example.tarefabonus.databinding.ActivityImccalculatorBinding
import viewModel.IMCCalculatorViewModel

class IMCCalculatorActivity : AppCompatActivity() {
    private lateinit var binding: ActivityImccalculatorBinding
    private lateinit var viewModel: IMCCalculatorViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityImccalculatorBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        viewModel = ViewModelProvider(this).get(IMCCalculatorViewModel::class.java)

        binding.btnCalculate.setOnClickListener {
            val weightStr = binding.etWeight.text.toString()
            val heightStr = binding.etHeight.text.toString()

            if (weightStr.isNotEmpty() && heightStr.isNotEmpty()) {
                val weight = weightStr.toDouble()
                val height = heightStr.toDouble()

                val result = viewModel.calculateIMC(weight, height)
                binding.tvResult.text = "Resultado: $result"
            } else {
                Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
