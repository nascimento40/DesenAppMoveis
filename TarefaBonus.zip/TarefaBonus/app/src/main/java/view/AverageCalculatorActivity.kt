package view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.example.tarefabonus.databinding.ActivityAverageCalculatorBinding
import viewModel.AverageCalculatorViewModel

class AverageCalculatorActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAverageCalculatorBinding
    private lateinit var viewModel: AverageCalculatorViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAverageCalculatorBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        viewModel = ViewModelProvider(this).get(AverageCalculatorViewModel::class.java)

        binding.btnCalculate.setOnClickListener {
            val scoresStr = binding.etScores.text.toString()
            val weightsStr = binding.etWeights.text.toString()

            val scores = scoresStr.split(",").map { it.toDouble() }
            val weights = weightsStr.split(",").map { it.toInt() }

            try {
                val result = viewModel.calculateWeightedAverage(scores, weights)
                binding.tvResult.text = "Resultado: $result"
            } catch (e: IllegalArgumentException) {
                Toast.makeText(this, e.message, Toast.LENGTH_SHORT).show()
            }
        }
    }
}
