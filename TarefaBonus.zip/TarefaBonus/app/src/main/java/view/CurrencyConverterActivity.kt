package view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.example.tarefabonus.databinding.ActivityCurrencyConverterBinding
import viewModel.CurrencyConverterViewModel

class CurrencyConverterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCurrencyConverterBinding
    private lateinit var viewModel: CurrencyConverterViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCurrencyConverterBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        viewModel = ViewModelProvider(this).get(CurrencyConverterViewModel::class.java)

        binding.btnConvert.setOnClickListener {
            val usdAmountStr = binding.etUSDAmount.text.toString()

            if (usdAmountStr.isNotEmpty()) {
                val usdAmount = usdAmountStr.toDouble()
                val result = viewModel.convertUSDToEUR(usdAmount)
                binding.tvResult.text = "Resultado: $result EUR"
            } else {
                Toast.makeText(this, "Digite a quantidade em USD", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
