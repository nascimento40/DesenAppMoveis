package com.example.prova.view

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.prova.databinding.ActivityCadastroBinding
import com.example.prova.viewModel.CadastroViewModel

class CadastroActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCadastroBinding
    private lateinit var viewModel: CadastroViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCadastroBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this).get(CadastroViewModel::class.java)

        binding.buttonCadastrar.setOnClickListener {
            val nome = binding.editTextNome.text.toString()
            val level = binding.editTextLevel.text.toString()
            val gear = binding.editTextGear.text.toString()

            val isCadastroSucesso = viewModel.cadastrarPlayer(nome, level, gear)

            if (isCadastroSucesso) {
                exibirToast("Jogador cadastrado com sucesso")
                finish()
            } else {
                exibirToast("Limite de jogadores atingido")
            }
        }
    }

    private fun exibirToast(mensagem: String) {
        Toast.makeText(this, mensagem, Toast.LENGTH_SHORT).show()
    }
}

