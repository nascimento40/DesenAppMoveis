package com.example.prova.repository

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.prova.R
import com.example.prova.view.CadastroActivity

class PlayerAdapter(val context: Context): RecyclerView.Adapter<PlayerViewHolder>() {
    val dao = PlayerDB.getInstance(context).getPlayersDAO()
    var listaPlayers = dao.buscarPlayers()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlayerViewHolder {
        val playerLayout = LayoutInflater.from(context)
            .inflate(R.layout.player_layout,parent,false)
        val playerViewHolder = PlayerViewHolder(playerLayout)
        return playerViewHolder
    }

    override fun getItemCount(): Int {
        return listaPlayers.size
    }

    override fun onBindViewHolder(holder: PlayerViewHolder, position: Int) {
        val player = listaPlayers.get(position)
        holder.txtNome.text = "Nome: ${player.nome}"
        holder.txtLevel.text = "Level: ${player.level}"
        holder.txtGear.text = "Gear: ${player.gear}"

        holder.txtNome.setOnClickListener {
            var intent = Intent(context, CadastroActivity::class.java)
            intent.putExtra("id",player.id)
            context.startActivity(intent)
        }

        holder.txtNome.setOnLongClickListener {
            dao.deletarPlayer(player)
            Toast.makeText(context, "Player excluído com sucesso!", Toast.LENGTH_SHORT).show()
            atualizarAdapter()

            true
        }
    }

    fun atualizarAdapter() {
        listaPlayers = emptyList()
        listaPlayers = dao.buscarPlayers()
        notifyDataSetChanged()
    }
}