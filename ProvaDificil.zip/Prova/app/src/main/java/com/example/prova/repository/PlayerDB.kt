package com.example.prova.repository

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.prova.model.Player

@Database(entities = [Player::class], version = 1)
abstract class PlayerDB: RoomDatabase() {
    abstract fun getPlayersDAO(): PlayerDAO

    companion object {
        private lateinit var INSTANCE : PlayerDB
        fun getInstance(context: Context): PlayerDB {
            if (!Companion::INSTANCE.isInitialized) {
                INSTANCE = Room.databaseBuilder(context, PlayerDB::class.java, "players_db")
                    .allowMainThreadQueries()
                    .build()
            }
            return INSTANCE
        }
    }
}