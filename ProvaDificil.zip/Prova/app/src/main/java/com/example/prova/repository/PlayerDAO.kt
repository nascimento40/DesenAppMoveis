package com.example.prova.repository

import androidx.room.*
import com.example.prova.model.Player

@Dao
interface PlayerDAO {

    @Insert
    fun salvarPlayer(player: Player): Long

    @Delete
    fun deletarPlayer(player: Player)

    @Update
    fun atualizarPlayer(player: Player)

    @Query("SELECT * FROM players")
    fun buscarPlayers() : List<Player>

    @Query("SELECT * FROM players WHERE id = :id")
    fun buscarPlayer(id: Int) : Player

    @Query("SELECT COUNT(*) FROM players")
    fun totalPlayers() : Int
}