package com.example.prova.repository

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.prova.R

class PlayerViewHolder(playerLayout: View): RecyclerView.ViewHolder(playerLayout) {
    val txtNome = playerLayout.findViewById<TextView>(R.id.txtNome)
    val txtLevel = playerLayout.findViewById<TextView>(R.id.txtLevel)
    val txtGear = playerLayout.findViewById<TextView>(R.id.txtGear)
}