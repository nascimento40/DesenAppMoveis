package com.example.prova.repository

import android.content.Context
import com.example.prova.model.Player

class PlayerRepository(context: Context) {

    private var dao = PlayerDB.getInstance(context).getPlayersDAO()

    fun salvar(player: Player) : Boolean {
        return dao.salvarPlayer(player) < 11
    }

    fun deletar (player: Player) {
        dao.deletarPlayer(player)
    }

    fun buscarPlayer (id: Int) : Player {
        return dao.buscarPlayer(id)
    }

    fun buscarPlayers () : List<Player> {
        return dao.buscarPlayers()
    }

    fun atualizar(player: Player){
        dao.atualizarPlayer(player)
    }

}