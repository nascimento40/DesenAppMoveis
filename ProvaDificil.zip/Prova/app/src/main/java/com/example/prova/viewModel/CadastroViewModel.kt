package com.example.prova.viewModel

import androidx.lifecycle.ViewModel
import com.example.prova.model.Player
import com.example.prova.repository.PlayerDAO

class CadastroViewModel(private val playerDao: PlayerDAO) : ViewModel() {

    fun cadastrarPlayer(nome: String, level: String, gear: String): Boolean {
        val totalPlayers = playerDao.totalPlayers()

        if (totalPlayers < 10) {
            val player = Player(0, nome, level, gear)
            playerDao.salvarPlayer(player)
            return true
        } else {
            return false
        }
    }
}

