package com.example.prova.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "players")
data class Player (
    @PrimaryKey(autoGenerate = true) @ColumnInfo(name = "id") var id: Int,
    @ColumnInfo(name = "nome") var nome: String,
    @ColumnInfo(name = "level") var level: String,
    @ColumnInfo(name = "gear") var gear: String
) {
}