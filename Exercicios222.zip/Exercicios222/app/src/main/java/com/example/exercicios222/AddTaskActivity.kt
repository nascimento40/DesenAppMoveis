package com.example.exercicios222

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.example.exercicios222.databinding.ActivityAddTaskBinding

class AddTaskActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddTaskBinding
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddTaskBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSaveTask.setOnClickListener {
            onSaveTaskClick()
        }

        sharedPreferences = getSharedPreferences("tasks", Context.MODE_PRIVATE)
    }

    fun onSaveTaskClick() {
        val taskText = binding.edtTask.text.toString()
        if (taskText.isNotBlank()) {
            val taskList = sharedPreferences.getString("task_list", "teste")

            //taskList.add(taskText)

            val editor = sharedPreferences.edit()
            editor.putString("task_list", taskList.toString())
            editor.apply()

            Toast.makeText(this, "Tarefa salva com sucesso!", Toast.LENGTH_SHORT).show()

            binding.edtTask.text.clear()
        } else {
            Toast.makeText(this, "Digite uma tarefa antes de salvar!", Toast.LENGTH_SHORT).show()
        }
    }
}

