package com.example.exercicios222

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.exercicios222.databinding.ActivityViewTaskBinding

class ViewTaskActivity : AppCompatActivity() {

    private lateinit var binding: ActivityViewTaskBinding
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityViewTaskBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPreferences = getSharedPreferences("tasks", Context.MODE_PRIVATE)

        val taskContent = sharedPreferences.getString("task_list", "teste")
        binding.txtTaskContent.text = taskContent.toString()
    }
}
