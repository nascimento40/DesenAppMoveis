package com.example.aula12

data class Tarefa (var nomeTarefa: String) {
}