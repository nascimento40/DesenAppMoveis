package com.example.aula18

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class Exemplo2ViewModel : ViewModel() {

    private var msgCadastro = MutableLiveData<String>()
    private var exemplo2Model = Exemplo2Model()

    fun getMsgCadastro() : LiveData<String> {
        return msgCadastro
    }

    fun cadastrar(nome: String, idade: String) {
        msgCadastro.value = exemplo2Model.validarCampos(nome, idade)
    }

}