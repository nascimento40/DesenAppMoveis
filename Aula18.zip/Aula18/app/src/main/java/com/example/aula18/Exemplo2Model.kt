package com.example.aula18

class Exemplo2Model {

    fun validarCampos(nome: String, idade: String) : String {
        if (nome.isEmpty() || idade.isEmpty()) {
            return "Preencha todos os campos"
        }

        if (idade.toInt() < 0 || idade.toInt() > 120) {
            return "Idade deve estar entre 0 e 120"
        }

        return "Cadastro concluído!"
    }
}