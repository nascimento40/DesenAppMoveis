package com.example.aula18

class Exemplo3Model {

    fun validarValores(largura: String, altura: String, profundidade: String): Float {
        if (largura.isEmpty() || altura.isEmpty() || profundidade.isEmpty()) {
            return 0f
        }

        if (largura.toFloat() <= 0 || altura.toFloat() <= 0 || profundidade.toFloat() <=0) {
            return 0f
        }

        return largura.toFloat() * altura.toFloat() * profundidade.toFloat()
    }
}