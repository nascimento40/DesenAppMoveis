package com.example.aula18

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class Exemplo1ViewModel : ViewModel() {

    private var txtTitulo = MutableLiveData<String>()

    fun getTxtTitulo() : LiveData<String> {
        return txtTitulo
    }

    init {
        txtTitulo.value = "Hello, there!"
    }
}