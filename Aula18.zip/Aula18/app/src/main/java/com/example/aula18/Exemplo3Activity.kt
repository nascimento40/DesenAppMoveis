package com.example.aula18

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import com.example.aula18.databinding.ActivityExemplo3Binding

class Exemplo3Activity : AppCompatActivity() {
    private lateinit var binding: ActivityExemplo3Binding
    private lateinit var exemplo3ViewModel: Exemplo3ViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityExemplo3Binding.inflate(layoutInflater)
        setContentView(binding.root)

        exemplo3ViewModel = ViewModelProvider(this).get(Exemplo3ViewModel::class.java)

        setObserver()

        exemplo3ViewModel.calcular("6", "4.5", "7")
    }

    fun setObserver() {
        exemplo3ViewModel.getTxtVolume().observe(this) {
            binding.txtVolume.text = it.toString()
        }
    }
}