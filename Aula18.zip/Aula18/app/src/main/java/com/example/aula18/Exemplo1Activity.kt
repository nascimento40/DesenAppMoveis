package com.example.aula18

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import com.example.aula18.databinding.ActivityExemplo1Binding

class Exemplo1Activity : AppCompatActivity() {
    private lateinit var binding: ActivityExemplo1Binding
    private lateinit var exemplo1ViewModel: Exemplo1ViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityExemplo1Binding.inflate(layoutInflater)
        setContentView(binding.root)

        // instaciar view model
        exemplo1ViewModel = ViewModelProvider(this).get(Exemplo1ViewModel::class.java)

        setObserver()
    }

    fun setObserver() {
        // registrar observadores de evento
        exemplo1ViewModel.getTxtTitulo().observe(this) {
            // sempre que holver alteração no valor txtTitulo da classe Exemplo1ViewModel, atualize a text view txtTitulo
            binding.txtTitulo.text = it
        }
    }
}