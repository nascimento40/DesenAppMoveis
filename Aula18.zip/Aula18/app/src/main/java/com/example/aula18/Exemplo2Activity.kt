package com.example.aula18

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.example.aula18.databinding.ActivityExemplo2Binding

class Exemplo2Activity : AppCompatActivity() {
    private lateinit var binding: ActivityExemplo2Binding
    private lateinit var exemplo2ViewModel: Exemplo2ViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityExemplo2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        exemplo2ViewModel = ViewModelProvider(this).get(Exemplo2ViewModel::class.java)

        setObserver()

        binding.btnCadastrar.setOnClickListener {
            var nome = binding.edtNome.text.toString()
            var idade = binding.edtIdade.text.toString()

            exemplo2ViewModel.cadastrar(nome, idade)
        }
    }

    fun setObserver() {
        exemplo2ViewModel.getMsgCadastro().observe(this){
            Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
            LimparCampos()
        }
    }

    fun LimparCampos() {
        binding.edtNome.text.clear()
        binding.edtIdade.text.clear()
    }
}