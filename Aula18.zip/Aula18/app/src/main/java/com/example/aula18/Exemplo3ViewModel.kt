package com.example.aula18

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class Exemplo3ViewModel : ViewModel() {

    private var txtVolume = MutableLiveData<Float>()
    private var exemplo3Model = Exemplo3Model()

    fun getTxtVolume() : LiveData<Float> {
        return txtVolume
    }

    fun calcular(largura: String, altura: String, profundidade: String) {
        txtVolume.value = exemplo3Model.validarValores(largura, altura, profundidade)
    }
}