package com.example.aula122

data class Carro (var marca: String, var modelo: String, var cor: String, var ano: Int) {
}