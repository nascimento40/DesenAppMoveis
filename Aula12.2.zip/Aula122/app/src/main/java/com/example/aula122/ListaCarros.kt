package com.example.aula122

class ListaCarros private constructor() {
    companion object {


        private var listaCarros = mutableListOf<Carro>()

        init {
            listaCarros.add(Carro("Nissa", "Versa", "Preto", 2017))
            listaCarros.add(Carro("Mitsubich", "Lancer", "Vermelho", 2016))
        }

        fun addCarro(carro: Carro) {
            listaCarros.add(carro)
        }

        fun getCarro(position: Int): Carro {
            return listaCarros.get(position)
        }

        fun removeCarro(position: Int) {
            listaCarros.removeAt(position)
        }

        fun getListSize() : Int {
            return listaCarros.size
        }
    }
}