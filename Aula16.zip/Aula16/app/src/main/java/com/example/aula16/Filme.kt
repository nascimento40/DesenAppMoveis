package com.example.aula16

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity (tableName = "filmes")
data class Filme(
    @PrimaryKey(autoGenerate = true) @ColumnInfo var id: Int,
    @ColumnInfo var titulo: String,
    @ColumnInfo var genero: String,
    @ColumnInfo var direcao: String
)