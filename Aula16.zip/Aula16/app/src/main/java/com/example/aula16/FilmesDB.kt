package com.example.aula16

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Filme::class], version = 1)
abstract class FilmesDB : RoomDatabase() {

    abstract fun getFilmeDAO() : FilmeDAO

    companion object {
        private lateinit var INSTANCE : FilmesDB

        fun getInstance(context: Context) : FilmesDB {
            if (!::INSTANCE.isInitialized) {
                // inicializa instancia
                INSTANCE = Room.databaseBuilder(context, FilmesDB::class.java, "filmes_db")
                    .allowMainThreadQueries()
                    .build()
            }
            return INSTANCE
        }
    }
}