package com.example.aula16

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface FilmeDAO {

    @Insert
    fun salvarFilme(filme: Filme): Long

    @Delete
    fun deletarFilme(filme: Filme)

    @Update
    fun atualizarFilme(filme: Filme)

    @Query("SELECT * FROM filmes WHERE id = :id")
    fun getFilme(id: Int): Filme

    @Query("SELECT * FROM filmes")
    fun getFilmes(): List<Filme>
}