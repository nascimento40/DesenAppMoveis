package com.example.aula16

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.aula16.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var filmeDAO = FilmesDB.getInstance(this).getFilmeDAO()

        var filme = filmeDAO.getFilme(1)
        binding.txtFilme.text = "Filme: ${filme.titulo}"
    }
}