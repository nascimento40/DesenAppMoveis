package com.example.aula6

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.aula6.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    // temporariamente, criaremos valores fixos para dados login
    private val EMAIL = "eliano@gmail.com"
    private val SENHA = "senha"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        // acao de clique do botao
        binding.btnEntrar.setOnClickListener {
            validarLogin()
        }
    }

    override fun onStop() {
        super.onStop()
        finish()
    }

    private fun validarLogin() {
        if (binding.edtEmail.text.isEmpty() || binding.edtSenha.text.isEmpty()) {
            // mensagem de erro
            exibirToast("Preencha todos os campos")
            return
        }

        var email = binding.edtEmail.text.toString()
        var senha = binding.edtSenha.text.toString()

        if (!email.equals(EMAIL) || !senha.equals(SENHA)) {
            exibirToast("E-mail ou senha invalidos!")
            binding.edtEmail.text.clear()
            binding.edtSenha.text.clear()
            return
        }

        //iniciar a main activity
        var intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    private fun exibirToast (mensagem : String) {
        Toast.makeText(this, mensagem, Toast.LENGTH_SHORT).show()
    }
}