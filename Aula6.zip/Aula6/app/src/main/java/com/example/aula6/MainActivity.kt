package com.example.aula6

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.example.aula6.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var mensagem : String
    private val TAG = "ESTADO" // val = constante
    private lateinit var binding: ActivityMainBinding
    /* lembrando que: ActivityMainBinding é uma classe de apoio criada pelo viewBinding para ajudar
    a buscar as referencias dos elementos da UI (activity_main.xml)
    */

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        // estamos inflando o layout presento no xml para dentro do objeto binding
        setContentView(binding.root)
        Log.d(TAG,"onCreate invocado")

        mensagem = "Hello, world!"
    }

    override fun onStart() {
        super.onStart()
        binding.txtMensagem.text = mensagem
        Log.d(TAG,"onStart invocado")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG,"onResume invocado")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG,"onPause invocado")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG,"onStop invocado")
        // finish() // mata a activity atual
    }

    override fun onRestart() {
        super.onRestart()
        mensagem = "Hello, again!"
        Log.d(TAG,"onRestart invocado")
    }
}