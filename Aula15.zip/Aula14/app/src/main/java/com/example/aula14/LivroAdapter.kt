package com.example.aula14

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class LivroAdapter(val context: Context) : RecyclerView.Adapter<LivroViewHolder>() {

    val dao = LivrosDB.getInstance(context).getLivrosDAO()
    var listaLivros = dao.buscarLivros()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LivroViewHolder {
        val livroLayout = LayoutInflater.from(context)
            .inflate(R.layout.livro_layout,parent,false)
        val livroViewHolder = LivroViewHolder(livroLayout)
        return livroViewHolder
    }

    override fun onBindViewHolder(holder: LivroViewHolder, position: Int) {
        val livro = listaLivros.get(position) // pegar livro de lista local aqui
        holder.txtTitulo.text = livro.titulo
        holder.txtAno.text = "Ano de lançamento: ${livro.ano}"
        holder.txtAutor.text = "Autor: ${livro.autor}"

        holder.txtTitulo.setOnClickListener {
            var intent = Intent(context, CadastroActivity::class.java)
            intent.putExtra("id",livro.id)
            context.startActivity(intent)
        }

        holder.txtTitulo.setOnLongClickListener {
            // deletar livro aqui
            dao.deletarLivro(livro)
            Toast.makeText(context, "Livro excluído com sucesso!", Toast.LENGTH_SHORT).show()
            atualizarAdapter()

            true
        }

    }

    override fun getItemCount(): Int {
        return listaLivros.size // retornar tamanho de lista local aqui
    }

    fun atualizarAdapter() {
        listaLivros = emptyList()
        listaLivros = dao.buscarLivros()
        notifyDataSetChanged()
    }
}