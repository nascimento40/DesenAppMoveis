package com.example.aula14

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.aula14.databinding.ActivityCadastroBinding

class CadastroActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCadastroBinding
    private val dao = LivrosDB.getInstance(this).getLivrosDAO()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCadastroBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var id = intent.getIntExtra("id", 0)
        if (id > 0) {
            var temp = dao.buscarLivros(id)
            binding.edtAutor.setText(temp.autor)
            binding.edtTitulo.setText(temp.titulo)
            binding.edtAno.setText(temp.ano)
        }

        binding.btnSalvar.setOnClickListener {
            validarDados()
        }
    }

    fun validarDados() {
        if (binding.edtTitulo.text.isEmpty() ||
                binding.edtAutor.text.isEmpty() ||
                binding.edtAno.text.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
            return
        }

        var livro = Livro(
            id,
            binding.edtTitulo.text.toString(),
            binding.edtAutor.text.toString(),
            binding.edtAno.text.toString().toInt()
        )

        // salvar ou editar livro aqui
        if (id > 0) {
            dao.atualizarLivro(livro)
            finish()
            return

        }
        if (dao.salvarLivro(livro) > 0) {
            Toast.makeText(this, "Livro cadastrado", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}