package com.example.aula14

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface LivrosDAO {

    @Insert
    fun salvarLivro(livro: Livro) : Long

    @Delete
    fun deletarLivro(livro: Livro)

    @Update
    fun atualizarLivro(livro: Livro)

    @Query("SELECT * FROM livros")
    fun buscarLivros() : List<Livro>

    @Query("SELECT * FROM livros WHERE id = :id")
    fun buscarLivro(id: Int) : Livro

    @Query("SELECT COUNT(*) FROM livros")
    fun totalLivros() : Int
}