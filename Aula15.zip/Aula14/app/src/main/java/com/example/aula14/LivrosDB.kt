package com.example.aula14

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Livro::class], version = 1)
abstract class LivrosDB : RoomDatabase() {

    abstract fun getLivrosDAO() : LivrosDAO

    companion object {
        private lateinit var INSTANCE : LivrosDB
        fun getInstance(context: Context) : LivrosDB {
            if (!::INSTANCE.isInitialized) {
                // inicializar instancia
                INSTANCE = Room.databaseBuilder(context, LivrosDB::class.java, "biblioteca")
                    .allowMainThreadQueries()
                    .build()
            }
            return INSTANCE
        }
    }
}