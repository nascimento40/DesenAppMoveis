package com.example.aula14

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "livros")
data class Livro(
    @PrimaryKey(autoGenerate = true) @ColumnInfo(name = "id") var id: Int,
    @ColumnInfo(name = "titulo") var titulo: String,
    @ColumnInfo(name = "autor") var autor: String,
    @ColumnInfo(name = "ano") var ano: Int
    )