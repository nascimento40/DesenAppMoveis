package com.example.aula14

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class LivroViewHolder(livroLayout : View) : RecyclerView.ViewHolder(livroLayout) {
    val txtTitulo = livroLayout.findViewById<TextView>(R.id.txtTitulo)
    val txtAno = livroLayout.findViewById<TextView>(R.id.txtAno)
    val txtAutor = livroLayout.findViewById<TextView>(R.id.txtAutor)
}