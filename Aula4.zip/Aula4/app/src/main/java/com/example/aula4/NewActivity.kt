package com.example.aula4

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.aula4.databinding.ActivityNewBinding

class NewActivity : AppCompatActivity() {
    // criar uma referencia para o view Binding
    private lateinit var binding: ActivityNewBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // inicial layout xml para dentro do 'binding'
        binding = ActivityNewBinding.inflate(layoutInflater)
        // facilitar o acesso ao root (a toda a camada view) do binding
        var view = binding.root // root = o layout do seu xml
        // setar este view como sendo o novo layout para esta classe
        setContentView(view)
        // açao de clique do botao btnCadastrarUsuario
        binding.btnCadastrarUsuario.setOnClickListener {
            var mensagem = ""
            if (validarCamposVazios()) {
                mensagem = "Preencha todos os campos"
            } else {
                mensagem = "Usuario cadastrado"
                binding.edtEmail.text.clear()
                binding.edtSenha.text.clear()
            }
            Toast.makeText(this, mensagem, Toast.LENGTH_SHORT).show()
        }
    }
    private fun validarCamposVazios() : Boolean {
        return binding.edtEmail.text.isEmpty() || binding.edtSenha.text.isEmpty()
    }
}