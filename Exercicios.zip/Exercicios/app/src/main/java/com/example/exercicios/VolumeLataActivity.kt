package com.example.exercicios

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.exercicios.databinding.ActivityVolumeLataBinding
import kotlin.math.PI

class VolumeLataActivity : AppCompatActivity() {

    private lateinit var binding: ActivityVolumeLataBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVolumeLataBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnCalculateVolume.setOnClickListener {
            calculateVolume()
        }
    }

    private fun calculateVolume() {
        val radius = binding.editTextRadius.text.toString().toDoubleOrNull()
        val height = binding.editTextHeight.text.toString().toDoubleOrNull()

        if (radius != null && height != null && radius >= 0 && height >= 0) {
            val volume = PI * radius * radius * height
            binding.textViewVolume.text = "Volume da lata de óleo: $volume"
        } else {
            binding.textViewVolume.text = "Entradas inválidas"
        }
    }
}