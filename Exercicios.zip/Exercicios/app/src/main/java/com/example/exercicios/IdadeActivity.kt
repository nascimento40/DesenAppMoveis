package com.example.exercicios

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.exercicios.databinding.ActivityIdadeBinding
import java.util.*

class IdadeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityIdadeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityIdadeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnCalculateAge.setOnClickListener {
            calculateAge(binding.editTextYearOfBirth.text.toString())
        }
    }

    private fun calculateAge(yearOfBirthText: String) {
        val currentYear = Calendar.getInstance().get(Calendar.YEAR)
        val yearOfBirth = yearOfBirthText.toIntOrNull()

        if (yearOfBirth != null && yearOfBirth >= 1900 && yearOfBirth <= currentYear) {
            val age = currentYear - yearOfBirth
            binding.textViewAge.text = "Idade: $age"
        } else {
            binding.textViewAge.text = "Data de nascimento inválida"
        }
    }
}
