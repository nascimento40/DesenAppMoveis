package com.example.exercicios

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.exercicios.databinding.ActivityVolumeBinding

class VolumeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityVolumeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVolumeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnCalculateVolume.setOnClickListener {
            calculateVolume()
        }
    }

    private fun calculateVolume() {
        val width = binding.editTextWidth.text.toString().toDoubleOrNull()
        val height = binding.editTextHeight.text.toString().toDoubleOrNull()
        val length = binding.editTextLength.text.toString().toDoubleOrNull()

        if (width != null && height != null && length != null) {
            val volume = width * height * length
            binding.textViewVolume.text = "Volume: $volume"
        } else {
            binding.textViewVolume.text = "Dados inválidos"
        }
    }
}
