package com.example.exercicios

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.exercicios.databinding.ActivitySalarioAumentoBinding

class SalarioAumentoActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySalarioAumentoBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySalarioAumentoBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        binding.btnCalculate.setOnClickListener {
            calculateSalaryIncrease()
        }
    }

    private fun calculateSalaryIncrease() {
        val currentSalary = binding.editTextSalary.text.toString().toDoubleOrNull()
        val percentageIncrease = binding.editTextPercentage.text.toString().toDoubleOrNull()

        if (currentSalary != null && percentageIncrease != null) {
            val increaseAmount = currentSalary * (percentageIncrease / 100)
            val newSalary = currentSalary + increaseAmount

            binding.textViewNewSalary.text = "Novo Salário: $newSalary"
            binding.textViewIncreaseAmount.text = "Valor de aumento: $increaseAmount"
        } else {
            binding.textViewNewSalary.text = "Dados inválidos"
            binding.textViewIncreaseAmount.text = ""
        }
    }
}