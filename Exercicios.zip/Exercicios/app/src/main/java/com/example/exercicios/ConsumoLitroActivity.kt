package com.example.exercicios

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.exercicios.databinding.ActivityConsumoLitroBinding

class ConsumoLitroActivity : AppCompatActivity() {

    private lateinit var binding: ActivityConsumoLitroBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityConsumoLitroBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnCalculateConsumption.setOnClickListener {
            calculateConsumption()
        }
    }

    private fun calculateConsumption() {
        val kilometers = binding.editTextKilometers.text.toString().toDoubleOrNull()
        val liters = binding.editTextLiters.text.toString().toDoubleOrNull()

        if (kilometers != null && liters != null && liters > 0) {
            val consumption = kilometers / liters
            binding.textViewConsumption.text = "Consumo: $consumption km/l"
        } else {
            binding.textViewConsumption.text = "Entrada inválida"
        }
    }
}
