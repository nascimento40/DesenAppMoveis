package com.example.exercicios

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.exercicios.databinding.ActivityMediaAlunoBinding

class MediaAlunoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMediaAlunoBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMediaAlunoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnCalculateAverage.setOnClickListener {
            calculateAverage()
        }
    }

    private fun calculateAverage() {
        val grade1 = binding.editTextGrade1.text.toString().toDoubleOrNull()
        val grade2 = binding.editTextGrade2.text.toString().toDoubleOrNull()
        val grade3 = binding.editTextGrade3.text.toString().toDoubleOrNull()
        val grade4 = binding.editTextGrade4.text.toString().toDoubleOrNull()

        if (grade1 != null && grade2 != null && grade3 != null && grade4 != null &&
            grade1 >= 0 && grade1 <= 10 &&
            grade2 >= 0 && grade2 <= 10 &&
            grade3 >= 0 && grade3 <= 10 &&
            grade4 >= 0 && grade4 <= 10) {

            val average = (grade1 + grade2 + grade3 + grade4) / 4
            binding.textViewAverage.text = "Média Final: $average"
        } else {
            binding.textViewAverage.text = "Notas inválidas"
        }
    }
}
