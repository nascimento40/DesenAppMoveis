package com.example.prova

data class Compromisso (var titulo: String, var data: String, var horaInicio: String,
                        var horaFim: String, var Descricao: String)